package mx.com.android.purchasesalecars.services

object EndPoint {
    // SETTINGS PRODUCT
    internal const val GET_CARS = "car/car_list"
}