package mx.com.android.purchasesalecars.util

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


/**
 * Creado por Raul Oropeza el 23/01/23 el 14/01/23
 */

object Constants {
    const val BASE_URL = "https://private-0110fd-iveroropeza.apiary-mock.com/"
    const val LOGTAG = "LOGS"

}